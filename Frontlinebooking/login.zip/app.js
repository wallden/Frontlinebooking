﻿
var app = angular.module("app", ["ui.router", "firebase"]);

app.config(function ($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/');

	var loginState = {
		name: 'login',
		url: '/login',
		templateUrl: 'login.html'
	}

	var mainState = {
		name: 'bookings',
		url: '/',
		templateUrl: 'bookings.html'
	}

	$stateProvider.state(loginState);
	$stateProvider.state(mainState);
	var config = {
		apiKey: "AIzaSyDxjbAbxibCjUmD044Ru_ctwyzBEEc_-Pk",
		authDomain: "frontlinebooking-2c056.firebaseapp.com",
		databaseURL: "https://frontlinebooking-2c056.firebaseio.com",
		storageBucket: "frontlinebooking-2c056.appspot.com",
		messagingSenderId: "973705531402"
	};
	firebase.initializeApp(config);
});
app.run(function ($state, userService, bookingsService) {

	firebase.auth()
		.onAuthStateChanged(function (user) {
			if (user) {
				var uid = user.uid;
				var userData = userService.setCurrentUser(uid);
				userData.$loaded((data) => {
					bookingsService.setBookings(data.company);
				});
				$state.go("bookings");
			} else {
				// User is signed out.
				// ...
			}
			// ...
		});

});
app.controller("bookingCtrl",
["bookingsService", "userService", function (bookingsService, userService) {

	this.initialize = (booking) => {
		this.booking = booking;
		console.log("init: " + booking.$id);
	}
	this.userService = userService;

	this.bookingsService = bookingsService;
	this.getUsersForBooking = () => {
		return this.bookingsService.getUsersForBooking(this.booking.$id);
	}
	this.makeBooking = () => {
		this.tempUserBooking.uid = this.userService.user.$id;
		this.bookingsService.addUserToBooking(this.booking.$id, this.tempUserBooking).then((result) => {
			this.tempUserBooking = null;
			this.closeBookingModal();
		}, (error) => {
			console.log(error);
		});
	}

	this.menuItems = ["", "Kycklingpasta 75:-", "Laxpasta 75:-", "Caesarsallad 85:-", "Smoothie 55:-"];
	this.openBookingModal = () => {
		document.getElementById('booking-' + this.booking.$id).style.display = 'block';
	}
	this.closeBookingModal = () => {
		document.getElementById('booking-' + this.booking.$id).style.display = 'none';
	}
	this.openBookedUsersModal = () => {
		document.getElementById('userlist-' + this.booking.$id).style.display = 'block';
	}
	this.closeBookedUsersModal = () => {
		document.getElementById('userlist-' + this.booking.$id).style.display = 'none';
	}
}
]);
app.controller("mainCtrl",
[
	"$state", "bookingsService", "userService", function ($state, bookingsService, userService) {
		this.user = firebase.auth().currentUser;
		if (!this.user) {
			$state.go("login");
		}
		this.userService = userService;
		this.bookingsService = bookingsService;

		this.openMoreInfoModal = () => {

		}
		this.signOut = () => {
			firebase.auth().signOut().then((result) => {
				$state.go("login");
				this.bookingsService.reset();
				this.userService.reset();
			}).catch((error) => {
				console.log(error);
			});
		}

	}
]);

app.controller("loginCtrl", ["bookingsService", "$state", function (bookingsService, $state) {
	this.user = firebase.auth().currentUser;
	if (this.user) {
		$state.go("bookings");
	}
	this.email = "";
	this.password = "";

	this.login = () => {
		this.isLoading = true;
		this.email.replace(/ /g, "");
		var email = this.email + "@frontlinebookings.se";
		var password = this.password;
		firebase.auth()
			.signInWithEmailAndPassword(email, password)
			.then((result) => {
				console.log(result);
				$state.go("bookings");
				this.isLoading = false;
			})
			.catch(function (error) {
				// Handle Errors here.
				console.log(error);
				var errorCode = error.code;
				var errorMessage = error.message;
				// ...
			});
	}
}
]);

app.service("bookingsService",
	function ($firebaseObject, $firebaseArray, userService) {
		this.bookings = [];
		this.bookingsUsers = {};
		this.reset = () => {
			this.bookingsUsers = {};
			this.bookings = [];

		}
		this.setBookings = (companyName) => {
			var ref = firebase.database().ref("Bookings/" + companyName + "/bookings");
			this.bookings = $firebaseArray(ref);
		}
		this.getUsersForBooking = (bookingId) => {
			if (!this.bookingsUsers[bookingId]) {
				var companyName = userService.user.company;
				var ref = firebase.database().ref("Bookings/" + companyName + "/bookings/" + bookingId + "/users");
				var users = $firebaseArray(ref);
				this.bookingsUsers[bookingId] = users;
				return users;
			}
			return this.bookingsUsers[bookingId];
		}
		this.addUserToBooking = (bookingId, user) => {
			return this.bookingsUsers[bookingId].$add(user);
		}

	});

app.service("userService", function ($firebaseObject) {
	this.user = {};
	this.reset = () => {
		this.user = {};
	}

	this.setCurrentUser = (uid) => {
		var ref = firebase.database().ref("Users/" + uid);
		this.user = $firebaseObject(ref);
		return this.user;
	}
})